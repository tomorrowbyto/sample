# MASTER_HOST=${MASTER_IP} && echo MASTER_HOST: ${MASTER_HOST}
# MASTER_PORT=${MASTER_PORT} && echo MASTER_PORT: ${MASTER_PORT}
# NODE_INDEX=${RANK} && echo NODE_INDEX: ${NODE_INDEX}
# # NODE_INDEX=${2} && echo NODE_INDEX: ${NODE_INDEX}
# PER_NODE_GPU=1 && echo PER_NODE_GPU: ${PER_NODE_GPU}
# NUM_NODE=${1} && echo NUM_NODE: ${NUM_NODE}
# LANGS=Python

# export NCCL_DEBUG=INFO
# export NCCL_SOCKET_IFNAME=ib
# export NCCL_NET=IB
# export NCCL_SOCKET_NTHREADS=8
# export NCCL_NSOCKS_PERTHREAD=8



PER_NODE_GPU=8
python -m torch.distributed.launch --nproc_per_node=${PER_NODE_GPU} run.py \
    --output_dir /drive/saved_models/tracelearner-singleline-weight-0923 \
    --data_cache_dir /drive/saved_models/tracelearner-singleline \
    --train_data_path /drive/single_line/single_line_pretrain.json \
    --eval_data_path /drive/single_line/single_line_dev.json \
    --model_name_or_path /drive/saved_models/tracelearner-singleline-weight-0909/checkpoint-300000-0.2386 \
    --block_size 1024 \
    --per_gpu_train_batch_size 4 \
    --per_gpu_eval_batch_size 8 \
    --gradient_accumulation_steps 8 \
    --learning_rate 4e-4 \
    --node_index=0 \
    --gpu_per_node $PER_NODE_GPU \
    --weight_decay 0.01 \
    --adam_epsilon 1e-6 \
    --max_grad_norm 1.0 \
    --max_steps 1000000 \
    --warmup_steps 10000 \
    --save_steps 5000 \
    --seed 123

