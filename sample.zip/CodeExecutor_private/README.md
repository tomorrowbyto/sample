CEL预训练的三阶段：

- CEL-S1 
- CEL-S2
- CEL-S3

CodeExecutor预训练的三阶段：

- CEL-S1 
- CodeExecutor-S2
- CodeExecutor-S3

CEL-S3-edge 、CodeExecutor-S3-edge：添加预训练任务Node Alignment (edge prediction)的版本

human_evaluation_handbook: 人工评价trace使用的手册

