import random
import torch
from torch.utils.data import Dataset
import os
import pickle
import logging
import json
from tqdm import tqdm


def _truncate_seq_pair(tokens_a, tokens_b, max_length):
    """Truncates a sequence pair in place to the maximum length."""
    while True:
        total_length = len(tokens_a) + len(tokens_b)
        if total_length <= max_length:
            break
        if len(tokens_a) > len(tokens_b):
            tokens_a.pop()
        else:
            tokens_b.pop()

def _truncate_seq_pair_two_length(tokens_a, tokens_b, max_length_a, max_length_b):
    """Truncates a sequence pair in place to the maximum length."""
    while True:
        total_length = len(tokens_a) + len(tokens_b)
        if total_length <= max_length_a + max_length_b:
            break
        if len(tokens_b) > max_length_b:
            tokens_b.pop()
        else: # len(tokens_a) > max_length_a
            tokens_a.pop()

class InputFeatures(object):
    """A single training/test features for a example."""
    def __init__(self,
                 code_tokens,
                 trace_tokens,
                 trace_to_code_list,
                 identifiers_list

    ):
        self.code_tokens = code_tokens
        self.trace_tokens = trace_tokens
        self.trace_to_code_list = trace_to_code_list
        self.identifiers_list = identifiers_list
        
def convert_examples_to_features(item):
    # parsing
    js,tokenizer=item
    code_tokens = js["code_tokens"]
    trace_tokens = js["trace_tokens"]
    trace_to_code = js["trace_to_code"]
    identifiers = js["identifiers"]

    code_tokens_all = tokenizer.tokenize(" ".join(code_tokens))
    # print(f"code_tokens_all: {code_tokens_all}")
    trace_tokens_all = tokenizer.tokenize(" ".join(trace_tokens))

    code_tokens=[tokenizer.tokenize('@ '+x)[1:] if idx!=0 else tokenizer.tokenize(x) for idx,x in enumerate(code_tokens)]
    code_ori2cur_pos={}
    code_ori2cur_pos[-1]=(0,0)
    for i in range(len(code_tokens)):
        code_ori2cur_pos[i]=(code_ori2cur_pos[i-1][1],code_ori2cur_pos[i-1][1]+len(code_tokens[i]))    
    code_tokens=[y for x in code_tokens for y in x]
    # print(f"code_tokens: {code_tokens}")
    # print(tokenizer.convert_tokens_to_ids(code_tokens_all))
    # print(tokenizer.convert_tokens_to_ids(code_tokens))
    # import pdb;pdb.set_trace()

    trace_tokens=[tokenizer.tokenize('@ '+x)[1:] if idx!=0 else tokenizer.tokenize(x) for idx,x in enumerate(trace_tokens)]
    trace_ori2cur_pos={}
    trace_ori2cur_pos[-1]=(0,0)
    for i in range(len(trace_tokens)):
        trace_ori2cur_pos[i]=(trace_ori2cur_pos[i-1][1],trace_ori2cur_pos[i-1][1]+len(trace_tokens[i]))    
    trace_tokens=[y for x in trace_tokens for y in x]

    # reindex trace_to_code
    trace_to_code_list = []
    for x in trace_to_code:
        for trace_idx in range(trace_ori2cur_pos[x[0]][0],trace_ori2cur_pos[x[0]][1]):
            for code_idx in range(code_ori2cur_pos[x[1]][0],code_ori2cur_pos[x[1]][1]):
                trace_to_code_list.append((trace_idx,code_idx))
    
    # reindex identifiers
    identifiers_list = []
    for x in identifiers:
        for code_idx in range(code_ori2cur_pos[x][0],code_ori2cur_pos[x][1]):
            identifiers_list.append(code_idx)

    return InputFeatures(code_tokens_all,trace_tokens_all,trace_to_code_list,identifiers_list)



class TextDataset(Dataset):
    def __init__(self, tokenizer, args, filename, local_rank, world_size, logger, mode):
        self.args = args
        self.tokenizer = tokenizer

        if args.tutorial == True:
            cached_features_file = os.path.join('{}'.format(args.data_cache_dir), "tutorial_word_size_"+str(world_size)+"_rank_"+str(local_rank)+'_size_'+ str(args.block_size)+'_'+mode+'.pkl')
        else:
            cached_features_file = os.path.join('{}'.format(args.data_cache_dir), "word_size_"+str(world_size)+"_rank_"+str(local_rank)+'_size_'+ str(args.block_size)+'_'+mode+'.pkl')
        if os.path.exists(cached_features_file):
            logger.warning("Loading features from cached file %s", cached_features_file)
            with open(cached_features_file, 'rb') as handle1:
                self.examples = pickle.load(handle1)
            if 'train' in mode and local_rank==0:
                for idx, example in enumerate(self.examples[:1]):
                        logger.warning("*** Example ***")
                        logger.warning("idx: %s",idx)
                        logger.warning("code_tokens: {}".format(' '.join(map(str, example.code_tokens))))   
                        logger.warning("trace_tokens: {}".format(' '.join(map(str, example.trace_tokens))))   
                        logger.warning("trace_to_code_list: {}".format(example.trace_to_code_list))     
                        logger.warning("identifiers_list: {}".format(example.identifiers_list))       
        else:
            self.examples = []
            total_num = 0
            error_num = 0
            logger.info("Load and create features from dataset file at %s", filename)
            num_lines = sum(1 for line in open(filename,'r'))
            with open(filename,"r",encoding="utf8") as f:
                for i,line in enumerate(tqdm(f,total=num_lines)):
                    json_line = json.loads(line)
                    if len(json_line['code_tokens']) != 0: 
                        total_num += 1
                        if (mode == "train" and total_num % world_size == local_rank) or (mode != "train" and local_rank in [-1, 0]):
                            js = {}
                            js["code_tokens"] = json_line["code_tokens"]
                            js["trace_tokens"] = json_line["trace_tokens"]
                            js["trace_to_code"] = json_line["trace_to_code"]
                            js["identifiers"] = json_line["identifiers"]

                            try:
                                features = convert_examples_to_features((js, tokenizer))
                                cur_index = len(self.examples)
                                self.examples.append(features)
                            except:
                                error_num += 1 
                    # if total_num == 32: break #debug

            if mode == "train" and local_rank==0:
                for idx, example in enumerate(self.examples[:1]):
                    logger.warning("*** Example ***")
                    logger.warning("idx: %s",idx)
                    logger.warning("code_tokens: {}".format(example.code_tokens))   
                    logger.warning("trace_tokens: {}".format(example.trace_tokens))
                    logger.warning("trace_to_code_list: {}".format(example.trace_to_code_list))     
                    logger.warning("identifiers_list: {}".format(example.identifiers_list)) 

            
            logger.warning("Num examples = %d: %d", local_rank,len(self.examples))
            logger.warning(f"Error num = {error_num}")
            # debug
            logger.warning("Saving features into cached file %s", cached_features_file)
            if not os.path.exists(args.data_cache_dir):
                os.makedirs(args.data_cache_dir)
            with open(cached_features_file, 'wb') as handle1:
                pickle.dump(self.examples, handle1, protocol=pickle.HIGHEST_PROTOCOL)
        
            


    def __len__(self):
        return len(self.examples)
    
    def __getitem__(self, item): 
        # import pdb;pdb.set_trace()
        # print(item)
        js = self.examples[item]  

        # Encoder-Decoder for Trace Generation
        source_tokens = js.code_tokens
        target_tokens = ["<mask0>"] + js.trace_tokens    
        _truncate_seq_pair_two_length(source_tokens,target_tokens,self.args.block_size//4 - 1, self.args.block_size//2 + self.args.block_size//4 - 5)   
        source_tokens = source_tokens + ["<mask0>"]
        text_tokens = ["<s>","<encoder-decoder>","</s>"] + source_tokens + ["</s>"] + target_tokens + ["</s>"]
        text_ids = self.tokenizer.convert_tokens_to_ids(text_tokens)
        dual_gen_ids = text_ids + [self.tokenizer.pad_token_id]*(self.args.block_size-len(text_ids)) 
        dual_gen_type_ids = [1] * len(["<s>","<encoder-decoder>","</s>"] + source_tokens + ["</s>"]) + [2] * len(target_tokens + ["</s>"]) + [0]*(self.args.block_size-len(text_ids))        

        # Encoder-Decoder for Node Alignment
        trace_to_code_ids = []
        for x in js.trace_to_code_list:
            if x[0] + 1 < len(target_tokens) and x[1] < len(source_tokens):
                trace_to_code_ids.append((x[0] + 5 + len(source_tokens), x[1] + 3)) 
                # print(text_tokens[x[0] + 5 + len(source_tokens)] + " " + text_tokens[x[1] + 3])
        identifier_ids = []
        for x in js.identifiers_list:
            if x < len(source_tokens):
                identifier_ids.append(x + 3)
                # print(text_tokens[x+3])
            
        edge_labels = torch.full([len(dual_gen_ids),len(dual_gen_ids)], -100)   
        # e.g. trace_to_code_ids = [(10,1), (12,3)] 
        edge_trace_ids = torch.tensor([e[0] for e in trace_to_code_ids])
        edge_code_ids = torch.tensor([e[1] for e in trace_to_code_ids])
        # 只限制edge_trace_ids所在行为0 （可选的位置为所有identidier的位置) 只选取20%去做预测
        select_ids = torch.bernoulli(torch.full(edge_trace_ids.shape, self.args.align_sample_percent)).bool() 
        edge_trace_ids = edge_trace_ids[select_ids].long()
        edge_code_ids = edge_code_ids[select_ids].long()
        edge_identifier_ids = torch.tensor([x for x in identifier_ids]).long()
        predict_zone = torch.zeros(1,len(edge_identifier_ids)).long()
        for x in edge_trace_ids:
            edge_labels[x,edge_identifier_ids] = predict_zone
        edge_labels[edge_trace_ids,edge_code_ids] = 1
        edge_labels = edge_labels.long()

        # from transformers import RobertaTokenizer
        # tokenizer = RobertaTokenizer.from_pretrained("../../drive/saved_models/tracelearner-tutorial-weight-1009/checkpoint-55000-1.2348")    
        # text = tokenizer.decode(dual_gen_ids,clean_up_tokenization_spaces=False)
        # print(f"text: {text}")
        # text2 = tokenizer.decode(dual_gen_ids,clean_up_tokenization_spaces=False,spaces_between_special_tokens=False)
        # print(f"text2: {text2}")

        return (
               torch.tensor(dual_gen_ids),
               torch.tensor(dual_gen_type_ids),  
               edge_labels,           
               )



            

    
